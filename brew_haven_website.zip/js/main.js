document.addEventListener("DOMContentLoaded", () => {
  console.log("Brew Haven site loaded");
});